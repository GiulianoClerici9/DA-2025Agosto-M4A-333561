package com.example.Obligatorio.servicios;

import java.util.ArrayList;
import java.util.List;

import com.example.Obligatorio.modelo.Bonificacion;
import com.example.Obligatorio.modelo.BonificacionAsignada;
import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.modelo.Puesto;


public class ServicioBonificaciones {

    private List<Bonificacion> bonificaciones;

    public ServicioBonificaciones() {
        this.bonificaciones = new ArrayList<>();
    }

    public void agregarBonificacion(Bonificacion b) {
        bonificaciones.add(b);
    }

    public List<Bonificacion> getBonificaciones() {
        return new ArrayList<>(bonificaciones);
    }

    public Bonificacion buscarPorNombre(String nombre) {
        for (Bonificacion b : bonificaciones) {
            if (b.getNombre().equalsIgnoreCase(nombre)) {
                return b;
            }
        }
        return null;
    }

    public List<String> obtenerNombresBonifiaciones() {
        List<String> nombres = new ArrayList<>();

        for (Bonificacion b : bonificaciones) {
            nombres.add(b.getNombre());
        }

        return nombres;
    }

    public Bonificacion buscarBonificacionPorNombre(String nombre) {
        Bonificacion resultado = null;
        if (nombre != null && !nombre.isBlank()) {

            for (Bonificacion b : bonificaciones) {
                if (b.getNombre().equalsIgnoreCase(nombre)) {
                    resultado = b;
                }
            }

        }
        return resultado;
    }

 public BonificacionAsignada obtenerBonificacionAplicable(Propietario prop, Puesto puesto) {
        if (prop == null || puesto == null) return null;

        for (BonificacionAsignada ba : prop.getBonificaciones()) {
            if (puesto.equals(ba.getPuesto())) {
                
                return ba;
            }
        }
        return null;
    }
}
