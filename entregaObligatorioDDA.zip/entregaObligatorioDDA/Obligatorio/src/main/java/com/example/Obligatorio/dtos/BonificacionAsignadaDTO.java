package com.example.Obligatorio.dtos;

public record BonificacionAsignadaDTO(
        String nombreBonificacion,
        String puesto,
        String fechaAsignada

        
) {}
