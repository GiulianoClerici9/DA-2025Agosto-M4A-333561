package com.example.Obligatorio.modelo.bonificaciones;

import com.example.Obligatorio.modelo.*;

import java.time.LocalDateTime;

public class Exonerados extends Bonificacion {

    public Exonerados() {
        super("Exonerados");
    }

    @Override
    public double calcularDescuento(Propietario prop, Vehiculo vehiculo, Puesto puesto, Tarifa tarifa, LocalDateTime fechaHora) {
        return tarifa.getMonto(); 
    }
}