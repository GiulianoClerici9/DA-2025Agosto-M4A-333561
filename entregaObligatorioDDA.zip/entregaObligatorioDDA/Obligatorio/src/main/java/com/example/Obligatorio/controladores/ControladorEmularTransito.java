package com.example.Obligatorio.controladores;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.*;

import com.example.Obligatorio.dtos.TarifaDTO;
import com.example.Obligatorio.modelo.Administrador;
import com.example.Obligatorio.modelo.BonificacionAsignada;
import com.example.Obligatorio.modelo.Notificacion;
import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.modelo.Puesto;
import com.example.Obligatorio.modelo.Tarifa;
import com.example.Obligatorio.modelo.Transito;
import com.example.Obligatorio.modelo.Vehiculo;
import com.example.Obligatorio.modelo.estados.DeshabilitadoState;
import com.example.Obligatorio.modelo.estados.PenalizadoState;
import com.example.Obligatorio.modelo.estados.SuspendidoState;
import com.example.Obligatorio.servicios.fachada.FachadaServicios;
import com.example.Obligatorio.utils.ConexionNavegador;
import com.example.Obligatorio.utils.Respuesta;

@RestController
@RequestMapping("/emularTransito")
@Scope("session")
public class ControladorEmularTransito {

        private final ConexionNavegador conexionNavegador;

        public ControladorEmularTransito(@Autowired ConexionNavegador conexionNavegador) {
                this.conexionNavegador = conexionNavegador;
        }

        private FachadaServicios fachada = FachadaServicios.getInstancia();

        @GetMapping("/vistaConectada")
        public List<Respuesta> inicializarVista(
                        @SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin) {

                if (admin == null) {
                        return Respuesta.lista(
                                        new Respuesta("usuarioNoAutenticado", "loginAdmin.html"));
                }

                List<String> puestos = fachada.obtenerNombresPuestos();

                return Respuesta.lista(
                                new Respuesta("listaPuestos", puestos));
        }

        @PostMapping("/cargarTarifas")
        public List<Respuesta> cargarTarifas(
                        @SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin,
                        @RequestParam String puesto) {

                if (admin == null) {
                        return Respuesta.lista(
                                        new Respuesta("usuarioNoAutenticado", "loginAdmin.html"));
                }

                if (puesto == null) {
                        return Respuesta.lista(
                                        new Respuesta("debeElegirPuesto", "Debe elegir un puesto"));

                }

                List<Tarifa> tarifas = fachada.obtenerTarifasDePuesto(puesto);

                List<TarifaDTO> listaDTO = tarifas.stream()
                                .map(t -> new TarifaDTO(
                                                t.getCategoria().getNombre(),
                                                t.getMonto()))
                                .toList();

                return Respuesta.lista(
                                new Respuesta("tarifas", listaDTO));

        }

        @PostMapping("/registrar")
        public List<Respuesta> registrar(
                        @RequestParam String matricula,
                        @RequestParam String fecha,
                        @RequestParam String puesto) {

                Vehiculo veh = fachada.buscarVehiculo(matricula);
                if (veh == null) {
                        return Respuesta.lista(new Respuesta("vehiculoNoExiste", "No existe el vehículo"));
                }

                Propietario prop = veh.getPropietario();
                Puesto p = fachada.buscarPuestoPorNombre(puesto);
                LocalDateTime fechaHora = fachada.parsearFecha(fecha);

                if (prop.getEstadoActual() instanceof DeshabilitadoState) {
                        return Respuesta.lista( new Respuesta("propietarioDeshabilitado","El propietario del vehículo está deshabilitado, no puede realizar tránsitos"));
                }

                if (prop.getEstadoActual() instanceof SuspendidoState) {
                        return Respuesta.lista(new Respuesta("propietarioSuspendido","El propietario del vehículo está suspendido, no puede realizar tránsitos"));
                }

                Tarifa tarifa = fachada.obtenerTarifaAplicable(veh, p);
                if (tarifa == null) {
                        return Respuesta.lista(new Respuesta("tarifaNoExiste", "No hay tarifa para esta categoría"));
                }

                double montoTarifa = tarifa.getMonto();

                BonificacionAsignada bonif = fachada.obtenerBonificacionAplicable(prop, p);

                double montoBonificacion = 0;
                String nombreBonif = "N/A";

                boolean esPenalizado = prop.getEstadoActual() instanceof PenalizadoState;

                if (!esPenalizado && bonif != null) {
                        montoBonificacion = bonif.getBonificacion()
                                        .calcularDescuento(prop, veh, p, tarifa, fechaHora);
                        nombreBonif = bonif.getBonificacion().getNombre();
                }

                double montoPagado = montoTarifa - montoBonificacion;

                if (prop.getSaldoActual() < montoPagado) {
                        return Respuesta.lista( new Respuesta("saldoInsuficiente","Saldo insuficiente: $" + prop.getSaldoActual()));
                }

                Transito t = new Transito(
                                p,
                                veh,
                                montoTarifa,
                                nombreBonif,
                                montoBonificacion,
                                montoPagado,
                                fechaHora);
                veh.agregarTransito(t);

                prop.debitar(montoPagado);

                if (!esPenalizado && prop.getSaldoActual() < prop.getSaldoMinimo()) {
                        Notificacion notif = new Notificacion( "Tu saldo actual es de $" + prop.getSaldoActual()+ ". Te recomendamos hacer una recarga.");prop.agregarNotificacion(notif);
                }

                return Respuesta.lista(
                                new Respuesta("propietario", prop.getNombreCompleto()),
                                new Respuesta("estado", prop.getEstadoActual().toString()),
                                new Respuesta("categoria", veh.getCategoria().getNombre()),
                                new Respuesta("bonificacion", nombreBonif),
                                new Respuesta("costo", montoPagado), 
                                new Respuesta("saldo", prop.getSaldoActual()));
        }
}
