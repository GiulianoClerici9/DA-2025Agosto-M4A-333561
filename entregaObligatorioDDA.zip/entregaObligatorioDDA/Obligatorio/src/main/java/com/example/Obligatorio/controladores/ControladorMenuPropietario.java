package com.example.Obligatorio.controladores;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.springframework.http.MediaType;

import com.example.Obligatorio.dtos.BonificacionAsignadaDTO;
import com.example.Obligatorio.dtos.TransitoDTO;
import com.example.Obligatorio.dtos.VehiculoDTO;
import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.modelo.Transito;
import com.example.Obligatorio.modelo.eventos.EventoNotificacion;
import com.example.Obligatorio.observador.Observable;
import com.example.Obligatorio.observador.Observador;
import com.example.Obligatorio.utils.ConexionNavegador;
import com.example.Obligatorio.utils.Respuesta;

@RestController
@RequestMapping("/menuPropietario")
@Scope("session")
public class ControladorMenuPropietario implements Observador<EventoNotificacion> {

    private final ConexionNavegador conexionNavegador;

    public ControladorMenuPropietario(@Autowired ConexionNavegador conexionNavegador) {
        this.conexionNavegador = conexionNavegador;
    }

    @GetMapping(value = "/registrarSSE", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter registrarSSE() {
        conexionNavegador.conectarSSE();
        return conexionNavegador.getConexionSSE();
    }

    @GetMapping("/vistaConectada")
    public List<Respuesta> inicializarVista(
            @SessionAttribute(name = "usuarioPropietario", required = false) Propietario propietario) {

        if (propietario == null) {
            return Respuesta.lista(new Respuesta("usuarioNoAutenticado", "loginPropietario.html"));
        }

        propietario.agregarObservador(this);
        System.out.println("✓ Observador registrado para " + propietario.getCedula());
       

        return Respuesta.lista(
                new Respuesta("nombreCompleto", propietario.getNombreCompleto()),
                new Respuesta("estado", propietario.getEstadoActual().toString()),
                new Respuesta("saldo", propietario.getSaldoActual()),
                new Respuesta("bonificaciones", obtenerBonificaciones(propietario)),
                new Respuesta("vehiculos", obtenerVehiculos(propietario)),
                new Respuesta("transitos", obtenerTransitos(propietario)),
                new Respuesta("notificaciones", propietario.getNotificaciones()));
    }

    private List<BonificacionAsignadaDTO> obtenerBonificaciones(Propietario p) {
        return p.getBonificaciones().stream()
                .map(b -> new BonificacionAsignadaDTO(
                        b.getBonificacion().getNombre(),
                        b.getPuesto().getNombre(),
                        b.getFechaAsignada().toString()))
                .collect(Collectors.toList());
    }

    private List<VehiculoDTO> obtenerVehiculos(Propietario p) {
        return p.getVehiculos().stream()
                .map(v -> new VehiculoDTO(
                        v.getMatricula(),
                        v.getModelo(),
                        v.getColor(),
                        v.getTransitos().size(),
                        v.getTransitos().stream().mapToDouble(Transito::getMontoPagado).sum()))
                .collect(Collectors.toList());
    }

    private List<TransitoDTO> obtenerTransitos(Propietario p) {
        return p.getVehiculos()
                .stream()
                .flatMap(v -> v.getTransitos().stream())
                .sorted((a, b) -> b.getFechaHora().compareTo(a.getFechaHora()))
                .map(t -> new TransitoDTO(
                        t.getPuesto().getNombre(),
                        t.getVehiculo().getMatricula(),
                        t.getVehiculo().getCategoria().getNombre(),
                        t.getMontoTarifa(),
                        t.getBonificacionAplicada(),
                        t.getMontoBonificacion(),
                        t.getMontoPagado(),
                        t.getFechaHora().toString()))
                .collect(Collectors.toList());
    }

    @PostMapping("/borrarNotificaciones")
    public List<Respuesta> borrarNotificaciones(
            @SessionAttribute(name = "usuarioPropietario", required = false) Propietario propietario) {

        if (propietario == null) {
            return Respuesta.lista(
                    new Respuesta("usuarioNoAutenticado", "loginPropietario.html"));
        }

        if (propietario.getNotificaciones().isEmpty()) {
            return Respuesta.lista(new Respuesta("noHayNotificaciones", "No hay notificaciones para borrar"));
        }

        propietario.borrarNotificaciones();

        return Respuesta.lista(new Respuesta("notificaciones", propietario.getNotificaciones()));
    }

    @Override
    public void actualizar(EventoNotificacion evento, Observable<EventoNotificacion> origen) {

        System.out.println("➡ Enviando SSE al propietario: " + evento.getMensaje());

        conexionNavegador.enviarJSON(
                Respuesta.lista(
                        new Respuesta("notificacion", evento)));
    }
}
