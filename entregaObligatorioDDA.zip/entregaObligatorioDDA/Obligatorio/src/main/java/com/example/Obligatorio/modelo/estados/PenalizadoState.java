package com.example.Obligatorio.modelo.estados;

public class PenalizadoState extends EstadoPropietario {


    public PenalizadoState() {}
    
    @Override
    public String getNombre() {
        return "Penalizado";
    }

    @Override
    public boolean aplicaBonificaciones() {
        return false;
    }

    @Override
    public boolean recibeNotificaciones() {
        return false;
    }

    @Override
    public String toString() {
        return "Penalizado";
    }
}
