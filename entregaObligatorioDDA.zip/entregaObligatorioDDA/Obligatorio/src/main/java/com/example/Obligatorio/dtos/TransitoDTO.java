package com.example.Obligatorio.dtos;

public record TransitoDTO(
        String puesto,
        String matricula,
        String categoria,
        double tarifa,
        String bonificacion,
        double descuento,
        double montoPagado,
        String fechaHora
) {}
