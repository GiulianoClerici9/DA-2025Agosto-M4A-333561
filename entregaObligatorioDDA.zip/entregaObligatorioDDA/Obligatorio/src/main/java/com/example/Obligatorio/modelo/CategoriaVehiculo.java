package com.example.Obligatorio.modelo;

public class CategoriaVehiculo {

    private String nombre;

    public CategoriaVehiculo(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre;
    }
}