package com.example.Obligatorio.modelo;

import java.util.ArrayList;
import java.util.List;

import com.example.Obligatorio.excepciones.ObligatorioException;

public class Puesto {

    private String nombre;
    private String direccion;
    private List<Tarifa> tarifas = new ArrayList<>();

    public Puesto(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public List<Tarifa> getTarifas() {
        return new ArrayList<>(tarifas);
    }

    public void agregarTarifa(Tarifa t) {
        if (t == null) {
            throw new IllegalArgumentException("La tarifa no puede ser nula");
        }
        tarifas.add(t);
    }

 
    public Tarifa obtenerTarifaPorCategoria(CategoriaVehiculo categoria) throws ObligatorioException {
        for (Tarifa t : tarifas) {
            if (t.getCategoria().equals(categoria)) {
                return t;
            }
        }
        throw new ObligatorioException("No existe tarifa para la categoría " + categoria.getNombre());
    }

    @Override
    public String toString() {
        return nombre;
    }
}