package com.example.Obligatorio.modelo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.Obligatorio.excepciones.ObligatorioException;
import com.example.Obligatorio.modelo.estados.EstadoPropietario;
import com.example.Obligatorio.modelo.estados.HabilitadoState;
import com.example.Obligatorio.modelo.eventos.EventoNotificacion;
import com.example.Obligatorio.observador.Observable;
import com.example.Obligatorio.observador.Observador;

import lombok.Getter;

public class Propietario extends Usuario implements Observador<EventoNotificacion> {

    Observable<EventoNotificacion> observable = new Observable<>();

    @Getter
    private double saldoActual;

    @Getter
    private double saldoMinimo;

    @Getter
    private EstadoPropietario estadoActual;

    private List<Vehiculo> vehiculos = new ArrayList<>();

    private List<BonificacionAsignada> bonificaciones = new ArrayList<>();
    private List<Notificacion> notificaciones = new ArrayList<>();

    public Propietario(
            String cedula,
            String contrasenia,
            String nombreCompleto,
            double saldoActual,
            double saldoMinimo) {
        super(cedula, contrasenia, nombreCompleto);
        this.saldoActual = saldoActual;
        this.saldoMinimo = saldoMinimo;
        this.estadoActual = new HabilitadoState();
    }

    public boolean puedeIngresarSistema() {
        return estadoActual.puedeIngresarSistema();
    }

    public boolean puedeRealizarTransito() {
        return estadoActual.puedeRealizarTransito();
    }

    public boolean aplicaBonificaciones() {
        return estadoActual.aplicaBonificaciones();
    }

    public boolean recibeNotificaciones() {
        return estadoActual.recibeNotificaciones();
    }

    public boolean puedeAsignarBonificacion() {
        return estadoActual.puedeAsignarBonificacion();
    }

    public void cambiarEstado(EstadoPropietario nuevoEstado) {
        this.estadoActual = nuevoEstado;
        Notificacion n = new Notificacion(
                "Se ha cambiado tu estado en el sistema. Tu estado actual es " + nuevoEstado.toString());
        this.agregarNotificacion(n);

        System.out.println(">>> [Propietario] Ejecutando notificarObservers...");
        EventoNotificacion evento = new EventoNotificacion(this.getCedula(), n.getMensaje());
        avisar(evento);

    }

    public void debitar(double monto) {

        saldoActual -= monto;
    }

    public void acreditar(double monto) {
        if (monto > 0)
            saldoActual += monto;
    }

    public void agregarVehiculo(Vehiculo v) {
        if (v != null)
            vehiculos.add(v);
    }

    public List<Vehiculo> getVehiculos() {
        return new ArrayList<>(vehiculos);
    }

    public void asignarBonificacion(Bonificacion bonificacion, Puesto puesto) throws ObligatorioException {

        BonificacionAsignada nueva = new BonificacionAsignada(bonificacion, puesto);
        bonificaciones.add(nueva);

        Map<String, Object> payload = new HashMap<>();
        payload.put("nombreBonificacion", bonificacion.getNombre());
        payload.put("puesto", puesto.getNombre());
        payload.put("fechaAsignada", LocalDateTime.now().toString());

        if (estadoActual.recibeNotificaciones()) {
            Notificacion n = new Notificacion("Se te asignó la bonificación " + bonificacion.getNombre() +
                    " para el puesto " + puesto.getNombre());
            notificaciones.add(n);

            EventoNotificacion ev = new EventoNotificacion(this.getCedula(), n.getMensaje(), payload);
            avisar(ev);
        }
    }

    public List<BonificacionAsignada> getBonificaciones() {
        return new ArrayList<>(bonificaciones);
    }

    public void agregarNotificacion(Notificacion n) {
        if (n != null)
            notificaciones.add(n);
    }

    public List<Notificacion> getNotificaciones() {
        return new ArrayList<>(notificaciones);
    }

    public void borrarNotificaciones() {
        notificaciones.clear();
    }

    @Override
    public void actualizar(EventoNotificacion evento, Observable<EventoNotificacion> origen) {
        if (this.recibeNotificaciones()) {

            LocalDateTime fecha = LocalDateTime.parse(evento.getFechaHora());

            Notificacion n = new Notificacion(
                    fecha,
                    evento.getMensaje());

            agregarNotificacion(n);
        }
    }

    public void agregarObservador(Observador<EventoNotificacion> obs) {
        System.out.println(">>> [Propietario] Observador agregado: " + obs.getClass().getSimpleName());
        observable.agregarObservador(obs);
    }

    public void quitarObservador(Observador<EventoNotificacion> obs) {
        observable.quitarObservador(obs);
    }

    
    public void avisar(EventoNotificacion evento) {
        observable.avisar(evento);
    }

}