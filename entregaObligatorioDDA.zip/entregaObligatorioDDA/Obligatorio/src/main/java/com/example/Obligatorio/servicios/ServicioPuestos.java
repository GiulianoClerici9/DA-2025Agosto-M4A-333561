package com.example.Obligatorio.servicios;

import java.util.ArrayList;
import java.util.List;

import com.example.Obligatorio.modelo.CategoriaVehiculo;
import com.example.Obligatorio.modelo.Puesto;
import com.example.Obligatorio.modelo.Tarifa;
import com.example.Obligatorio.modelo.Vehiculo;

public class ServicioPuestos {

    private List<Puesto> puestos;

    public ServicioPuestos() {
        this.puestos = new ArrayList<>();
    }

    public void agregarPuesto(Puesto p) {
        puestos.add(p);
    }

    public List<Puesto> getPuestos() {
        return new ArrayList<>(puestos);
    }

    public void agregarTarifa(Puesto p, Tarifa t) {
        if (p != null && t != null) {
            p.agregarTarifa(t);
        }
    }

    public Puesto buscarPorNombre(String nombre) {
        for (Puesto p : puestos) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                return p;
            }
        }
        return null;
    }

    public List<String> obtenerNombresPuestos() {
        List<String> nombres = new ArrayList<>();

        for (Puesto p : puestos) {
            nombres.add(p.getNombre());
        }

        return nombres;
    }

    public Puesto buscarPuestoPorNombre(String nombre) {
        Puesto encontrado = null;

        if (nombre != null && !nombre.isBlank()) {
            for (Puesto p : puestos) {
                if (p.getNombre().equalsIgnoreCase(nombre)) {
                    encontrado = p;
                }
            }
        }

        return encontrado;
    }

    public List<Tarifa> obtenerTarifasDePuesto(String nombrePuesto) {
        Puesto p = buscarPuestoPorNombre(nombrePuesto);
        return p.getTarifas();
    }

    public Tarifa obtenerTarifaAplicable(Vehiculo vehiculo, Puesto puesto) {
        CategoriaVehiculo cat = vehiculo.getCategoria();

        for (Tarifa t : puesto.getTarifas()) {
            if (t.getCategoria().equals(cat)) {
                return t;
            }
        }

        return null;
    }
}
