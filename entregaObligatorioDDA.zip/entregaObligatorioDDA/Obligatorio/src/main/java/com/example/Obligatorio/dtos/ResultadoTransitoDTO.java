package com.example.Obligatorio.dtos;


public class ResultadoTransitoDTO {

        private String nombrePropietario;
        private String estadoPropietario;
        private String categoriaVehiculo;
        private String bonificacionAplicada;
        private double montoPagado;
        private double saldoFinal;

        public ResultadoTransitoDTO(String nombrePropietario,
                        String estadoPropietario,
                        String categoriaVehiculo,
                        String bonificacionAplicada,
                        double montoPagado,
                        double saldoFinal) {
                this.nombrePropietario = nombrePropietario;
                this.estadoPropietario = estadoPropietario;
                this.categoriaVehiculo = categoriaVehiculo;
                this.bonificacionAplicada = bonificacionAplicada;
                this.montoPagado = montoPagado;
                this.saldoFinal = saldoFinal;
        }

        public String getNombrePropietario() {
                return nombrePropietario;
        }

        public String getEstadoPropietario() {
                return estadoPropietario;
        }

        public String getCategoriaVehiculo() {
                return categoriaVehiculo;
        }

        public String getBonificacionAplicada() {
                return bonificacionAplicada;
        }

        public double getMontoPagado() {
                return montoPagado;
        }

        public double getSaldoFinal() {
                return saldoFinal;
        }
}