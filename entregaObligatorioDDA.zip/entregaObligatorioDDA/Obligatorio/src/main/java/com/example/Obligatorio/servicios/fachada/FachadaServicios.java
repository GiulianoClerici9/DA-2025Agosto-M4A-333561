package com.example.Obligatorio.servicios.fachada;

import java.time.LocalDateTime;
import java.util.List;


import com.example.Obligatorio.excepciones.ObligatorioException;
import com.example.Obligatorio.modelo.Administrador;
import com.example.Obligatorio.modelo.Bonificacion;
import com.example.Obligatorio.modelo.BonificacionAsignada;
import com.example.Obligatorio.modelo.CategoriaVehiculo;

import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.modelo.Puesto;
import com.example.Obligatorio.modelo.Tarifa;

import com.example.Obligatorio.modelo.Vehiculo;
import com.example.Obligatorio.modelo.estados.EstadoPropietario;
import com.example.Obligatorio.modelo.eventos.EventoNotificacion;
import com.example.Obligatorio.observador.Observable;
import com.example.Obligatorio.observador.Observador;
import com.example.Obligatorio.servicios.ServicioBonificaciones;
import com.example.Obligatorio.servicios.ServicioCategorias;
import com.example.Obligatorio.servicios.ServicioPuestos;
import com.example.Obligatorio.servicios.ServicioUsuarios;
import com.example.Obligatorio.servicios.ServicioVehiculos;

public class FachadaServicios extends Observable<EventoNotificacion> {

    private static FachadaServicios instancia;
    private ServicioUsuarios sUsuarios;
    private ServicioPuestos sPuestos;
    private ServicioVehiculos sVehiculos;
    private ServicioCategorias sCategorias;
    private ServicioBonificaciones sBonificaciones;

    private FachadaServicios() {
        sUsuarios = new ServicioUsuarios();
        sPuestos = new ServicioPuestos();
        sVehiculos = new ServicioVehiculos();
        sCategorias = new ServicioCategorias();
        sBonificaciones = new ServicioBonificaciones();
    }

    public void agregarObservador(Observador<EventoNotificacion> obs) {
        super.agregarObservador(obs);
    }

    public void agregarAdministrador(Administrador usuario) {
        sUsuarios.agregar(usuario);
    }

    public void agregarPropietario(Propietario usuario) {
        sUsuarios.agregar(usuario);
    }

    public void agregarCategoriaVehiculo(CategoriaVehiculo c) {
        sCategorias.agregarCategoria(c);
    }

    public void agregarPuesto(Puesto p) {
        sPuestos.agregarPuesto(p);
    }

    public void agregarTarifa(Puesto p, Tarifa t) {
        sPuestos.agregarTarifa(p, t);
    }

    public void agregarVehiculo(Vehiculo v) {
        sVehiculos.agregarVehiculo(v);
    }

    public void agregarBonificacion(Bonificacion b) {
        sBonificaciones.agregarBonificacion(b);
    }

    public static FachadaServicios getInstancia() {
        if (instancia == null) {
            instancia = new FachadaServicios();
        }
        return instancia;
    }

    public Propietario loginPropietario(String cedula, String contrasenia) throws ObligatorioException {
        return sUsuarios.loginPropietario(cedula, contrasenia);
    }

    public Administrador loginAdministrador(String cedula, String contrasenia) throws ObligatorioException {
        return sUsuarios.loginAdministrador(cedula, contrasenia);
    }

    public Propietario buscarPropietarioPorCedula(String cedula) {
        return sUsuarios.buscarPropietarioPorCedula(cedula);
    }

    public List<String> obtenerNombresEstadosPropietario() {
        return sUsuarios.obtenerNombresEstados();
    }

    public EstadoPropietario cambiarEstadoPropietario(String estado, Propietario p) throws ObligatorioException {
        return sUsuarios.cambiarEstadoPropietario(estado, p);
    }

    public List<String> obtenerNombresPuestos() {
        return sPuestos.obtenerNombresPuestos();
    }

    public List<String> obtenerNombresBonifiaciones() {
        return sBonificaciones.obtenerNombresBonifiaciones();
    }

    public Bonificacion buscarBonificacionPorNombre(String nombre) {
        return sBonificaciones.buscarBonificacionPorNombre(nombre);
    }

    public List<Tarifa> obtenerTarifasDePuesto(String puesto) {
        return sPuestos.obtenerTarifasDePuesto(puesto);
    }

    public Puesto buscarPuestoPorNombre(String nombre) {
        return sPuestos.buscarPuestoPorNombre(nombre);
    }

    public Vehiculo buscarVehiculo(String matricula) {
        return sVehiculos.buscarVehiculo(matricula);
    }

    public LocalDateTime parsearFecha(String fechaStr) {
        return sUsuarios.parsearFecha(fechaStr);
    }

    public Tarifa obtenerTarifaAplicable(Vehiculo v, Puesto p) {
        return sPuestos.obtenerTarifaAplicable(v, p);
    }

    public BonificacionAsignada obtenerBonificacionAplicable(Propietario prop, Puesto puesto) {
        return sBonificaciones.obtenerBonificacionAplicable(prop, puesto);
    }

}
