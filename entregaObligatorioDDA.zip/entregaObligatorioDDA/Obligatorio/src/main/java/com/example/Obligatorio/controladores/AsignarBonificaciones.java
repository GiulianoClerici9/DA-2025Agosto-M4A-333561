package com.example.Obligatorio.controladores;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.example.Obligatorio.dtos.BonificacionAsignadaDTO;
import com.example.Obligatorio.excepciones.ObligatorioException;
import com.example.Obligatorio.modelo.Administrador;
import com.example.Obligatorio.modelo.Bonificacion;
import com.example.Obligatorio.modelo.BonificacionAsignada;
import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.modelo.Puesto;
import com.example.Obligatorio.servicios.fachada.FachadaServicios;
import com.example.Obligatorio.utils.Respuesta;

@RestController
@RequestMapping("/asignarBonificacion")
@Scope("session")
public class AsignarBonificaciones {

    private Propietario propietarioEnUso;

    private FachadaServicios fachada = FachadaServicios.getInstancia();

    @GetMapping("/vistaConectada")
    public List<Respuesta> inicializarVista(
            @SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin)
            throws ObligatorioException {

        if (admin == null) {
            return Respuesta.lista(
                    new Respuesta("usuarioNoAutenticado", "loginAdmin.html"));
        }

        List<String> bonificaciones = fachada.obtenerNombresBonifiaciones();
        List<String> puestos = fachada.obtenerNombresPuestos();

        if (propietarioEnUso != null) {
            List<BonificacionAsignadaDTO> dtos = obtenerBonificacionesDTO(propietarioEnUso);

            return Respuesta.lista(
                    new Respuesta("nombreCompleto", propietarioEnUso.getNombreCompleto()),
                    new Respuesta("estado", propietarioEnUso.getEstadoActual().toString()),
                    new Respuesta("bonificacionesAsignadas", dtos),

                    new Respuesta("listaBonificaciones", bonificaciones),
                    new Respuesta("listaPuestos", puestos));
        }

        return Respuesta.lista(
                new Respuesta("listaBonificaciones", bonificaciones),
                new Respuesta("listaPuestos", puestos));
    }

    @PostMapping("/buscarPropietarioBonificacion")
    public List<Respuesta> buscarPropietario(
            @SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin,
            @RequestParam String cedula) throws ObligatorioException {

        if (admin == null) {
            return Respuesta.lista(
                    new Respuesta("usuarioNoAutenticado", "loginAdmin.html"));
        }

        Propietario p = fachada.buscarPropietarioPorCedula(cedula);

        if (p == null) {
            return Respuesta.lista(
                    new Respuesta("noExistePropietario", "No existe el propietario"));

        }

        this.propietarioEnUso = p;

        List<BonificacionAsignadaDTO> dtos = new ArrayList<>();

        for (BonificacionAsignada ba : p.getBonificaciones()) {
            BonificacionAsignadaDTO dto = new BonificacionAsignadaDTO(
                    ba.getBonificacion().getNombre(),
                    ba.getPuesto().getNombre(),
                    ba.getFechaAsignada().toString());
            dtos.add(dto);
        }

        return Respuesta.lista(
                new Respuesta("nombreCompleto", p.getNombreCompleto()),
                new Respuesta("estado", p.getEstadoActual().toString()),
                new Respuesta("bonificacionesAsignadas", dtos));
    }

    @PostMapping("/asignar")
    public List<Respuesta> asignarBonificacion(
            @SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin,
            @RequestParam String cedula,
            @RequestParam String bonificacion,
            @RequestParam String puesto) throws ObligatorioException {

        if (admin == null) {
            return Respuesta.lista(
                    new Respuesta("usuarioNoAutenticado", "loginAdmin.html"));
        }

        if (bonificacion == null || bonificacion.isEmpty()) {
            return Respuesta.lista(
                    new Respuesta("debeElegirBonificacion", "Debe especificar una bonificación"));
        }

        if (puesto == null || puesto.isEmpty()) {
            return Respuesta.lista(
                    new Respuesta("debeElegirPuesto", "Debe especificar un puesto"));
        }

        Propietario p = fachada.buscarPropietarioPorCedula(cedula);

        if (p == null) {
            return Respuesta.lista(
                    new Respuesta("noExistePropietario", "No existe el propietario"));
        }

        if (!p.getEstadoActual().puedeAsignarBonificacion()) {
            return Respuesta.lista(
                    new Respuesta("propietarioDeshabilitado",
                            "El propietario está deshabilitado. No se pueden asignar bonificaciones"));
        }

        Bonificacion b = fachada.buscarBonificacionPorNombre(bonificacion);
        if (b == null) {
            return Respuesta.lista(
                    new Respuesta("debeElegirBonificacion", "Debe especificar una bonificación válida"));
        }

        Puesto pu = fachada.buscarPuestoPorNombre(puesto);
        if (pu == null) {
            return Respuesta.lista(
                    new Respuesta("debeElegirPuesto", "Debe especificar un puesto válido"));
        }
        for (BonificacionAsignada ba : p.getBonificaciones()) {
            if (ba.getPuesto().getNombre().equalsIgnoreCase(puesto)) {
                return Respuesta.lista(
                        new Respuesta("yaTieneBonificacion",
                                "Ya tiene una bonificación asignada para ese puesto"));
            }
        }

        p.asignarBonificacion(b, pu);
        this.propietarioEnUso = p;

        return Respuesta.lista(
                new Respuesta("bonificacionAsignada", "Bonificación asignada correctamente"),
                new Respuesta("bonificacionesAsignadas", obtenerBonificacionesDTO(p)));
    }

    private List<BonificacionAsignadaDTO> obtenerBonificacionesDTO(Propietario p) {
        List<BonificacionAsignadaDTO> lista = new ArrayList<>();

        for (BonificacionAsignada ba : p.getBonificaciones()) {
            lista.add(new BonificacionAsignadaDTO(
                    ba.getBonificacion().getNombre(),
                    ba.getPuesto().getNombre(),
                    ba.getFechaAsignada().toString()));
        }

        return lista;
    }

}
