package com.example.Obligatorio.modelo;

import lombok.Getter;

public abstract class Usuario {

    @Getter
    private String cedula;

    private String contrasenia;

    @Getter
    private String nombreCompleto;

    public Usuario(String cedula, String contrasenia, String nombreCompleto) {
        this.cedula = cedula;
        this.contrasenia = contrasenia;
        this.nombreCompleto = nombreCompleto;
    }

    @Override
    public String toString() {
        return nombreCompleto;
    }

    public boolean coincideContrasenia(String pwd) {
        return this.contrasenia != null && this.contrasenia.equals(pwd);
    }
}