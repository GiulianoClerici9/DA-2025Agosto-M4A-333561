package com.example.Obligatorio.controladores;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.example.Obligatorio.modelo.Administrador;
import com.example.Obligatorio.utils.ConexionNavegador;
import com.example.Obligatorio.utils.Respuesta;

@RestController
@RequestMapping("/menuAdministrador")
@Scope("session")
public class ControladorMenuAdministrador {

    private final ConexionNavegador conexionNavegador;

    public ControladorMenuAdministrador(@Autowired ConexionNavegador conexionNavegador) {
        this.conexionNavegador = conexionNavegador;
    }

    @GetMapping(value = "/registrarSSE", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter registrarSSE() {
        conexionNavegador.conectarSSE();
        return conexionNavegador.getConexionSSE();
    }


    @GetMapping("/vistaConectada")
    public List<Respuesta> inicializarVista(@SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin) {

        if (admin == null) {
            return Respuesta.lista(
                    new Respuesta("usuarioNoAutenticado", "loginAdmin.html")
            );
        }

        return Respuesta.lista(
                new Respuesta("nombreCompleto", admin.getNombreCompleto())
        );
    }
}
