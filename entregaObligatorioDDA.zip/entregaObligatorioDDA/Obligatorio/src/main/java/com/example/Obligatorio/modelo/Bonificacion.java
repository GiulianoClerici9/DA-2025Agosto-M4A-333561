package com.example.Obligatorio.modelo;

import java.time.LocalDateTime;

public abstract class Bonificacion {

    private String nombre;

    public Bonificacion(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public abstract double calcularDescuento(Propietario prop, Vehiculo vehiculo, Puesto puesto, Tarifa tarifa, LocalDateTime fechaHora);
}