package com.example.Obligatorio.controladores;

import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Obligatorio.excepciones.ObligatorioException;
import com.example.Obligatorio.modelo.Administrador;
import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.servicios.fachada.FachadaServicios;
import com.example.Obligatorio.utils.Respuesta;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/acceso")

public class ControladorLogin {

    @PostMapping("/loginPropietario")
    public List<Respuesta> loginPropietario(HttpSession sesionHttp, @RequestParam String cedula,
            @RequestParam String contrasenia) throws ObligatorioException {

        Propietario usuarioLogueado = FachadaServicios.getInstancia().loginPropietario(cedula, contrasenia);
        sesionHttp.setAttribute("usuarioPropietario", usuarioLogueado);
        return Respuesta.lista(new Respuesta("loginExitoso", "menuPropietario.html"));
    }

    @PostMapping("/logoutPropietario")
    public List<Respuesta> logoutPropietario(HttpSession sesionHttp) {
        Propietario usuario = (Propietario) sesionHttp.getAttribute("usuarioPropietario");
        if (usuario != null) {
            sesionHttp.removeAttribute("usuarioPropietario");
            sesionHttp.invalidate();
        }
        return Respuesta.lista(new Respuesta("usuarioNoAutenticado", "index.html"));
    }

    @PostMapping("/loginAdmin")
    public List<Respuesta> loginAdmin(HttpSession sesionHttp, @RequestParam String cedula,
            @RequestParam String contrasenia) throws ObligatorioException {

        if (sesionHttp.getAttribute("usuarioAdmin") != null) {
            throw new ObligatorioException("Ud. ya está logueado");
        }

        Administrador usuarioLogueado = FachadaServicios.getInstancia().loginAdministrador(cedula, contrasenia);
        sesionHttp.setAttribute("usuarioAdmin", usuarioLogueado);
        return Respuesta.lista(new Respuesta("loginExitoso", "menuAdministrador.html"));
    }

    @PostMapping("/logoutAdmin")
    public List<Respuesta> logoutAdmin(HttpSession sesionHttp) {
        Administrador usuario = (Administrador) sesionHttp.getAttribute("usuarioAdmin");
        if (usuario != null) {
            sesionHttp.removeAttribute("usuarioAdmin");
            sesionHttp.invalidate();
        }
        return Respuesta.lista(new Respuesta("usuarioNoAutenticado", "index.html"));
    }

}
