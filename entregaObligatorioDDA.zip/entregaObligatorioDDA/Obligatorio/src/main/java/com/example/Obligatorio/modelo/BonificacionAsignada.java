package com.example.Obligatorio.modelo;


import lombok.Getter;

import java.time.LocalDateTime;

@Getter
public class BonificacionAsignada {

    private Bonificacion bonificacion;
    private Puesto puesto;
    private LocalDateTime fechaAsignada;

    public BonificacionAsignada(Bonificacion bonificacion, Puesto puesto) {
        this.bonificacion = bonificacion;
        this.puesto = puesto;
        this.fechaAsignada = LocalDateTime.now();
    }
}
