package com.example.Obligatorio.modelo.estados;

public class DeshabilitadoState extends EstadoPropietario {


    public DeshabilitadoState() {}
    
    @Override
    public String getNombre() {
        return "Deshabilitado";
    }

    @Override
    public boolean puedeIngresarSistema() {
        return false;
    }

    @Override
    public boolean puedeRealizarTransito() {
        return false;
    }

    @Override
    public boolean puedeAsignarBonificacion() {
        return false;
    }

    @Override
    public String toString() {
        return "Deshabilitado";
    }
}
