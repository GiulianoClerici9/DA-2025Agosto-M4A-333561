package com.example.Obligatorio.dtos;

public record PuestoDTO(int id, String nombre) {}
