package com.example.Obligatorio.controladores;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;

import org.springframework.web.bind.annotation.*;


import com.example.Obligatorio.excepciones.ObligatorioException;

import com.example.Obligatorio.modelo.Administrador;
import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.modelo.estados.EstadoPropietario;
import com.example.Obligatorio.modelo.eventos.EventoNotificacion;
import com.example.Obligatorio.servicios.fachada.FachadaServicios;
import com.example.Obligatorio.utils.ConexionNavegador;
import com.example.Obligatorio.utils.Respuesta;

@RestController
@RequestMapping("/asignarEstado")
@Scope("session")
public class ControladorCambiarEstadoPropietario {

    private final ConexionNavegador conexionNavegador;
    private FachadaServicios fachada = FachadaServicios.getInstancia();

    public ControladorCambiarEstadoPropietario(@Autowired ConexionNavegador conexionNavegador) {
        this.conexionNavegador = conexionNavegador;
    }

    @GetMapping("/vistaConectada")
    public List<Respuesta> inicializarVista(
            @SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin)
            throws ObligatorioException {

        if (admin == null) {
            return Respuesta.lista(
                    new Respuesta("usuarioNoAutenticado", "loginAdmin.html"));
        }

        List<String> estados = fachada.obtenerNombresEstadosPropietario();

        return Respuesta.lista(
                new Respuesta("nombreCompleto", admin.getNombreCompleto()),
                new Respuesta("listaEstados", estados));
    }

    @PostMapping("/buscarPropietarioEstado")
    public List<Respuesta> buscarPropietario(
            @SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin,
            @RequestParam String cedula) throws ObligatorioException {

        if (admin == null) {
            return Respuesta.lista(
                    new Respuesta("usuarioNoAutenticado", "loginAdmin.html"));
        }

        Propietario p = fachada.buscarPropietarioPorCedula(cedula);

        if (p == null) {
            return Respuesta.lista(
                    new Respuesta("noExistePropietario", "No existe el propietario"));
        }

        return Respuesta.lista(
                new Respuesta("nombreCompleto", p.getNombreCompleto()),
                new Respuesta("estadoActual", p.getEstadoActual().toString()));
    }

    @PostMapping("/cambiarEstado")
    public List<Respuesta> cambiarEstado(
            @SessionAttribute(name = "usuarioAdmin", required = false) Administrador admin,
            @RequestParam String cedula,
            @RequestParam String estado) {

        if (admin == null) {
            return Respuesta.lista(
                    new Respuesta("usuarioNoAutenticado", "loginAdmin.html"));
        }

        Propietario p = fachada.buscarPropietarioPorCedula(cedula);

        if (p == null) {
            return Respuesta.lista(
                    new Respuesta("noExistePropietario", "No existe el propietario"));
        }

        if (p.getEstadoActual().getNombre().equalsIgnoreCase(estado)) {
            return Respuesta.lista(
                    new Respuesta("estadoIgual",
                            "El propietario ya está en estado " + p.getEstadoActual().getNombre()));
        }

        EstadoPropietario nuevo;
        try {
            nuevo = fachada.cambiarEstadoPropietario(estado, p);
        } catch (ObligatorioException e) {
            return Respuesta.lista(
                    new Respuesta("error", e.getMessage()));
        }

        p.cambiarEstado(nuevo); 

        EventoNotificacion evento = new EventoNotificacion("Estado cambiado",
                "El estado del propietario " + p.getNombreCompleto() + " ha sido cambiado a " + nuevo.toString());
        
        conexionNavegador.enviarJSON(Respuesta.lista(new Respuesta("notificacion", evento)));

        return Respuesta.lista(
                new Respuesta("estadoCambiado", "Estado cambiado correctamente"),
                new Respuesta("estadoActual", nuevo.toString()));
    }
}