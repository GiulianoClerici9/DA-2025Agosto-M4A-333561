package com.example.Obligatorio.excepciones;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice

public class GlobalExceptionHandler {
    private final int errorCodeStatus = 299; 

    @ExceptionHandler(ObligatorioException.class)
    public ResponseEntity<String> manejarException(ObligatorioException ex) {

       return ResponseEntity.status(errorCodeStatus).body(ex.getMessage());
    }
}
