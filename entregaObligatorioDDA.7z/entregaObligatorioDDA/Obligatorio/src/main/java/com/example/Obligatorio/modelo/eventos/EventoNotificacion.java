package com.example.Obligatorio.modelo.eventos;

import java.time.LocalDateTime;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class EventoNotificacion {

    private String cedulaDestinatario;
    private String mensaje;
    private LocalDateTime fechaHora;
    private Object payload;

    public EventoNotificacion(String cedula, String mensaje) {
        this.cedulaDestinatario = cedula;
        this.mensaje = mensaje;
        this.fechaHora = LocalDateTime.now();
    }

    public EventoNotificacion(String cedula, String mensaje, Object payload) {
        this.cedulaDestinatario = cedula;
        this.mensaje = mensaje;
        this.payload = payload;
        this.fechaHora = LocalDateTime.now();
    }

    public String getFechaHora() {
        return fechaHora.toString();
    }
}