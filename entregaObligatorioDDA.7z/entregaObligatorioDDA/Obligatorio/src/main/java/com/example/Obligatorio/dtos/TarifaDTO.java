package com.example.Obligatorio.dtos;

public record TarifaDTO(String categoria, double monto) {}
