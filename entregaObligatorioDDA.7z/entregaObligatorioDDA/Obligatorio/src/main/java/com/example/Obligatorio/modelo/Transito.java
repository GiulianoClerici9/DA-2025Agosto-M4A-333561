package com.example.Obligatorio.modelo;

import java.time.LocalDateTime;

public class Transito {

    private Puesto puesto;
    private Vehiculo vehiculo;
    private double montoTarifa;
    private String bonificacionAplicada; 
    private double montoBonificacion;
    private double montoPagado;
    private LocalDateTime fechaHora;

    public Transito(Puesto puesto, Vehiculo vehiculo, double montoTarifa,
                    String bonificacionAplicada, double montoBonificacion,
                    double montoPagado, LocalDateTime fechaHora) {

        this.puesto = puesto;
        this.vehiculo = vehiculo;
        this.montoTarifa = montoTarifa;
        this.bonificacionAplicada = bonificacionAplicada;
        this.montoBonificacion = montoBonificacion;
        this.montoPagado = montoPagado;
        this.fechaHora = fechaHora;
    }

    public Puesto getPuesto() {
        return puesto;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public double getMontoTarifa() {
        return montoTarifa;
    }

    public String getBonificacionAplicada() {
        return bonificacionAplicada;
    }

    public double getMontoBonificacion() {
        return montoBonificacion;
    }

    public double getMontoPagado() {
        return montoPagado;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }
}
