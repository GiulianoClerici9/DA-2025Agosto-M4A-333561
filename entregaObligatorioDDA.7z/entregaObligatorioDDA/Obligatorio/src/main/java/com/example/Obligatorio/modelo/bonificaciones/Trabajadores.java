package com.example.Obligatorio.modelo.bonificaciones;

import com.example.Obligatorio.modelo.*;

import java.time.DayOfWeek;
import java.time.LocalDateTime;

public class Trabajadores extends Bonificacion {

    public Trabajadores() {
        super("Trabajadores");
    }

    @Override
    public double calcularDescuento(Propietario prop, Vehiculo vehiculo,
                                    Puesto puesto, Tarifa tarifa, LocalDateTime fechaHora) {

        DayOfWeek dia = fechaHora.getDayOfWeek();

        boolean esDiaSemana = dia != DayOfWeek.SATURDAY && dia != DayOfWeek.SUNDAY;

        if (esDiaSemana) {
            return tarifa.getMonto() * 0.8; 
        }

        return 0;
    }
}