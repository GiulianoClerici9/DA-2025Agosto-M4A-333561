package com.example.Obligatorio.excepciones;

public class ObligatorioException extends Exception {
    public ObligatorioException(String message) {
        super(message);
    }
}
