package com.example.Obligatorio.modelo;

public class Tarifa {

    private CategoriaVehiculo categoria;
    private double monto;

    public Tarifa(CategoriaVehiculo categoria, double monto) {
        this.categoria = categoria;
        this.monto = monto;
    }

    public CategoriaVehiculo getCategoria() {
        return categoria;
    }

    public double getMonto() {
        return monto;
    }
}