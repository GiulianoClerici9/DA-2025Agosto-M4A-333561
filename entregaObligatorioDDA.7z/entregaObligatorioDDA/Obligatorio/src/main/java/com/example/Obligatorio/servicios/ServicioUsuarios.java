package com.example.Obligatorio.servicios;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.example.Obligatorio.excepciones.ObligatorioException;
import com.example.Obligatorio.modelo.Administrador;
import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.modelo.Usuario;
import com.example.Obligatorio.modelo.estados.DeshabilitadoState;
import com.example.Obligatorio.modelo.estados.EstadoPropietario;
import com.example.Obligatorio.modelo.estados.HabilitadoState;
import com.example.Obligatorio.modelo.estados.PenalizadoState;
import com.example.Obligatorio.modelo.estados.SuspendidoState;

public class ServicioUsuarios {

    private List<Propietario> usuarios;
    private List<Administrador> administradores;

    public ServicioUsuarios() {
        this.usuarios = new ArrayList<>();
        this.administradores = new ArrayList<>();
    }

    public void agregar(Administrador usuario) {
        administradores.add(usuario);
    }

    public void agregar(Propietario usuario) {
        usuarios.add(usuario);
    }

    private Usuario login(String ced, String pwd, List lista) {
        Usuario usuario;
        for (Object o : lista) {
            usuario = (Usuario) o;
            if (usuario.getCedula().equals(ced) && usuario.coincideContrasenia(pwd)) {
                return usuario;
            }
        }
        return null;
    }

    public Propietario loginPropietario(String cedula, String contrasenia) throws ObligatorioException {

        Propietario usuario = (Propietario) login(cedula, contrasenia, usuarios);

        if (usuario == null)
            throw new ObligatorioException("Acceso denegado");

        if (!usuario.getEstadoActual().puedeIngresarSistema())
            throw new ObligatorioException("Usuario deshabilitado, no puede ingresar al sistema");

        return usuario;
    }

    public Administrador loginAdministrador(String cedula, String contrasenia) throws ObligatorioException {

        Administrador usuario = (Administrador) login(cedula, contrasenia, administradores);
        if (usuario != null) {
            return usuario;
        }
        throw new ObligatorioException("Acceso denegado");
    }

    public Propietario buscarPropietarioPorCedula(String cedula) {
        for (Propietario p : usuarios) {
            if (p.getCedula().equals(cedula))
                return p;
        }
        return null;
    }

    public List<String> obtenerNombresEstados() {
        return List.of("Habilitado", "Deshabilitado", "Suspendido", "Penalizado");
    }

    public EstadoPropietario cambiarEstadoPropietario(String nombreEstado, Propietario p) throws ObligatorioException {

        if (nombreEstado == null || p == null) {
            throw new ObligatorioException("Datos inválidos para cambiar estado.");
        }

        switch (nombreEstado.toLowerCase()) {
            case "habilitado":
                return new HabilitadoState();

            case "deshabilitado":
                return new DeshabilitadoState();

            case "suspendido":
                return new SuspendidoState();

            case "penalizado":
                return new PenalizadoState();

            default:
                throw new ObligatorioException("Estado no reconocido: " + nombreEstado);
        }
    }

    public LocalDateTime parsearFecha(String fechaStr) {
        
        return LocalDateTime.parse(fechaStr);
    }

     public void actualizarSaldo(Propietario p, double montoPagado) {
        if (p != null) {
            p.debitar(montoPagado);
        }
    }

}
