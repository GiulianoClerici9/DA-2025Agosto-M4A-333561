package com.example.Obligatorio.modelo.estados;



public abstract class EstadoPropietario {

    public abstract String getNombre();

    public boolean puedeIngresarSistema()      { return true; }
    public boolean puedeRealizarTransito()     { return true; }
    public boolean aplicaBonificaciones()      { return true; }
    public boolean recibeNotificaciones()      { return true; }
    public boolean puedeAsignarBonificacion()  { return true; }

    
}