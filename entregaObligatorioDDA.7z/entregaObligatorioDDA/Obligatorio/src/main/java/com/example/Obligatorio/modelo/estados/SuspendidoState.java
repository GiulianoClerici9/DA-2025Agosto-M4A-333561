package com.example.Obligatorio.modelo.estados;

public class SuspendidoState extends EstadoPropietario {


    public SuspendidoState() {} 
    
    @Override
    public String getNombre() {
        return "Suspendido";
    }

    @Override
    public boolean puedeRealizarTransito() {
        return false;
    }

    @Override
    public String toString() {
        return "Suspendido";
    }
}
