package com.example.Obligatorio.modelo.bonificaciones;

import com.example.Obligatorio.modelo.*;


import java.time.LocalDateTime;

public class Frecuentes extends Bonificacion {

    public Frecuentes() {
        super("Frecuentes");
    }

    @Override
    public double calcularDescuento(Propietario prop, Vehiculo vehiculo, Puesto puesto, Tarifa tarifa, LocalDateTime fechaHora) {

        long transitosHoy = vehiculo.cantidadTransitosHoyEnPuesto(puesto, fechaHora.toLocalDate());

        if (transitosHoy >= 1) {
            return tarifa.getMonto() * 0.5; 
        }

        return 0; 
    }
}