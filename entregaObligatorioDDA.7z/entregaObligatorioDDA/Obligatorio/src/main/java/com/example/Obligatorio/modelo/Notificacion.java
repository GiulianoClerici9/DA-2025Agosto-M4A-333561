package com.example.Obligatorio.modelo;

import java.time.LocalDateTime;

import lombok.Getter;
public class Notificacion {
    @Getter
    private LocalDateTime fecha;
    @Getter
    private String mensaje;

    public Notificacion(String mensaje) {
        this.fecha = LocalDateTime.now();
        this.mensaje = mensaje;
    }

    public Notificacion(LocalDateTime fecha, String mensaje) {
        this.fecha = fecha;
        this.mensaje = mensaje;
    }
}
