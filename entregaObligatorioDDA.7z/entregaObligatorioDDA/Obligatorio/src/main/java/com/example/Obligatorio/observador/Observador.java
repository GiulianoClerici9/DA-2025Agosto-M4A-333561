package com.example.Obligatorio.observador;

public interface Observador <T>{
        public void actualizar(T evento,Observable<T> origen);
}
