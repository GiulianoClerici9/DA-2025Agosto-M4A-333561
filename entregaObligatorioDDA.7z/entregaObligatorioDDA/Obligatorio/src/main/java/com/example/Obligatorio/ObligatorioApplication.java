package com.example.Obligatorio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.Obligatorio.excepciones.ObligatorioException;
import com.example.Obligatorio.modelo.Administrador;
import com.example.Obligatorio.modelo.Bonificacion;
import com.example.Obligatorio.modelo.CategoriaVehiculo;
import com.example.Obligatorio.modelo.Notificacion;
import com.example.Obligatorio.modelo.Propietario;
import com.example.Obligatorio.modelo.Puesto;
import com.example.Obligatorio.modelo.Tarifa;
import com.example.Obligatorio.modelo.Vehiculo;
import com.example.Obligatorio.modelo.bonificaciones.Exonerados;
import com.example.Obligatorio.modelo.bonificaciones.Frecuentes;
import com.example.Obligatorio.modelo.bonificaciones.Trabajadores;
import com.example.Obligatorio.modelo.estados.DeshabilitadoState;
import com.example.Obligatorio.modelo.estados.SuspendidoState;
import com.example.Obligatorio.servicios.fachada.FachadaServicios;

@SpringBootApplication
public class ObligatorioApplication {

	public static void main(String[] args) throws ObligatorioException {
		SpringApplication.run(ObligatorioApplication.class, args);
		cargarDatosDePrueba();
	}

	private static void cargarDatosDePrueba() throws ObligatorioException {

		FachadaServicios f = FachadaServicios.getInstancia();

		// -------------------------------------------------
		// 1) Administradores
		// -------------------------------------------------
		Administrador admin1 = new Administrador("12345678", "admin.123", "Usuario Administrador");
		Administrador admin2 = new Administrador("87654321", "admin.456", "Administrador Secundario");
		f.agregarAdministrador(admin1);
		f.agregarAdministrador(admin2);

		// -------------------------------------------------
		// 2) Propietarios
		// -------------------------------------------------
		Propietario prop1 = new Propietario("23456789", "prop.123", "Usuario Propietario", 2000, 500);
		Propietario prop2 = new Propietario("34567890", "prop.456", "Propietario Deshabilitado", 1500, 300);
		prop2.cambiarEstado(new DeshabilitadoState());
		f.agregarPropietario(prop1);
		f.agregarPropietario(prop2);

		Propietario prop3 = new Propietario("45678901", "prop.789", "Propietario Suspendido", 3000, 800);
		prop3.cambiarEstado(new SuspendidoState());
		f.agregarPropietario(prop3);

		// -------------------------------------------------
		// 3) Categorías de Vehículos
		// -------------------------------------------------
		CategoriaVehiculo auto = new CategoriaVehiculo("(A) Automóvil");
		CategoriaVehiculo camion = new CategoriaVehiculo("(B) Camión");
		CategoriaVehiculo moto = new CategoriaVehiculo("(C) Moto");

		f.agregarCategoriaVehiculo(auto);
		f.agregarCategoriaVehiculo(camion);
		f.agregarCategoriaVehiculo(moto);

		// -------------------------------------------------
		// 4) Puestos
		// -------------------------------------------------
		Puesto p1 = new Puesto("Puesto A", "Ruta 1 - Km 23");
		Puesto p2 = new Puesto("Puesto B", "Ruta 5 - Km 56");
		Puesto p3 = new Puesto("Puesto C", "Ruta Interbalnearia - Km 32");

		f.agregarPuesto(p1);
		f.agregarPuesto(p2);
		f.agregarPuesto(p3);

		// -------------------------------------------------
		// 5) Tarifas por puesto
		// -------------------------------------------------
		// Puesto A
		f.agregarTarifa(p1, new Tarifa(auto, 120));
		f.agregarTarifa(p1, new Tarifa(camion, 300));
		f.agregarTarifa(p1, new Tarifa(moto, 80));

		// Puesto B
		f.agregarTarifa(p2, new Tarifa(auto, 150));
		f.agregarTarifa(p2, new Tarifa(camion, 350));
		f.agregarTarifa(p2, new Tarifa(moto, 90));

		// Puesto C
		f.agregarTarifa(p3, new Tarifa(auto, 100));
		f.agregarTarifa(p3, new Tarifa(camion, 280));
		f.agregarTarifa(p3, new Tarifa(moto, 70));

		// -------------------------------------------------
		// 6) Vehículos
		// -------------------------------------------------
		Vehiculo v1 = new Vehiculo("SBA1234", "Fiat Uno", "Rojo", auto, prop1);
		Vehiculo v2 = new Vehiculo("SBC5678", "Honda Civic", "Negro", auto, prop1);
		Vehiculo v3 = new Vehiculo("SBD9012", "Yamaha FZ", "Azul", moto, prop2);
		Vehiculo v4 = new Vehiculo("SBE3456", "Scania R500", "Blanco", camion, prop3);

		f.agregarVehiculo(v1);
		f.agregarVehiculo(v2);
		f.agregarVehiculo(v3);
		f.agregarVehiculo(v4);

		// Además, asignar vehículos al propietario
		prop1.agregarVehiculo(v1);
		prop1.agregarVehiculo(v2);
		prop2.agregarVehiculo(v3);
		prop3.agregarVehiculo(v4);

		// -------------------------------------------------
		// 7) Bonificaciones (tipos)
		// -------------------------------------------------
		Bonificacion exo = new Exonerados();
		Bonificacion frec = new Frecuentes();
		Bonificacion trab = new Trabajadores();

		f.agregarBonificacion(exo);
		f.agregarBonificacion(frec);
		f.agregarBonificacion(trab);

		// === Precarga de notificaciones para prop1 ===
		prop1.agregarNotificacion(new Notificacion(
				"Pasaste por el puesto Central con el vehículo SAA1234"));

		prop1.agregarNotificacion(new Notificacion(
				"Tu saldo actual es de $1500. Te recomendamos hacer una recarga"));

		prop1.agregarNotificacion(new Notificacion(
				"Nueva bonificación asignada: Frecuentes en Puesto Oeste"));

		

	}

}
