package com.example.Obligatorio.modelo;

public class Administrador extends Usuario{
    public Administrador(String cedula, String contrasenia, String nombreCompleto) {
        super(cedula, contrasenia, nombreCompleto);
    }
}
