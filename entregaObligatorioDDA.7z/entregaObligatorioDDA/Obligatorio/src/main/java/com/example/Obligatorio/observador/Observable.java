package com.example.Obligatorio.observador;

import java.util.ArrayList;
import java.util.List;

public class Observable<T> {

    private List<Observador<T>> observadores = new ArrayList<>();

    public void agregarObservador(Observador<T> obs) {
        if (!observadores.contains(obs)) {
            observadores.add(obs);
        }
    }

    public void quitarObservador(Observador<T> obs) {
        observadores.remove(obs);
    }

    public void avisar(T evento) {
        List<Observador<T>> copia = new ArrayList<>(observadores);
        for (Observador<T> obs : copia) {
            obs.actualizar(evento, this);
        }
    }
}