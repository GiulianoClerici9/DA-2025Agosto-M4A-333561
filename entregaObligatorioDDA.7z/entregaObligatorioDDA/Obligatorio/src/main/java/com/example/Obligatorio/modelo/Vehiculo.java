package com.example.Obligatorio.modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.Obligatorio.modelo.eventos.EventoNotificacion;
import com.example.Obligatorio.observador.Observable;

public class Vehiculo extends Observable<EventoNotificacion>  {

    private String matricula;
    private String modelo;
    private String color;
    private CategoriaVehiculo categoria;
    private Propietario propietario;

    private List<Transito> transitos = new ArrayList<>();

    public Vehiculo(String matricula, String modelo, String color, 
                    CategoriaVehiculo categoria, Propietario propietario) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.color = color;
        this.categoria = categoria;
        this.propietario = propietario;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public CategoriaVehiculo getCategoria() {
        return categoria;
    }

    public Propietario getPropietario() {
        return propietario;
    }

    public List<Transito> getTransitos() {
        return new ArrayList<>(transitos);
    }

    public void agregarTransito(Transito t) {
         if (t == null) return;

        transitos.add(t);

        String mensaje = "Pasaste por el puesto " +
                t.getPuesto().getNombre() +
                " con el vehículo " + this.matricula;

        Map<String, Object> payload = new HashMap<>();
        payload.put("tipo", "TRANSITO");
        payload.put("puesto", t.getPuesto().getNombre());
        payload.put("categoria", t.getVehiculo().getCategoria().getNombre());
        payload.put("bonificacionAplicada", t.getBonificacionAplicada());
        payload.put("montoPagado", t.getMontoPagado());
        payload.put("fechaHora", t.getFechaHora().toString());
        payload.put("nuevoSaldo", propietario.getSaldoActual());


        Notificacion notif = new Notificacion(mensaje);
        propietario.agregarNotificacion(notif);

        EventoNotificacion evento = new EventoNotificacion(propietario.getCedula(), mensaje, payload );

        propietario.avisar(evento);
    }
    

    public long cantidadTransitosHoyEnPuesto(Puesto p, LocalDate hoy) {
        return transitos.stream()
                .filter(t -> t.getPuesto().equals(p) && t.getFechaHora().toLocalDate().equals(hoy))
                .count();
    }

    @Override
    public String toString() {
        return matricula;
    }
}
