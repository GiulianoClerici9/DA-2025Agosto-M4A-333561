package com.example.Obligatorio.servicios;

import java.util.ArrayList;
import java.util.List;

import com.example.Obligatorio.modelo.CategoriaVehiculo;

public class ServicioCategorias {

    private List<CategoriaVehiculo> categorias;

    public ServicioCategorias() {
        this.categorias = new ArrayList<>();
    }

    public void agregarCategoria(CategoriaVehiculo c) {
        categorias.add(c);
    }

    public List<CategoriaVehiculo> getCategorias() {
        return new ArrayList<>(categorias);
    }

    public CategoriaVehiculo buscarPorNombre(String nombre) {
        for (CategoriaVehiculo c : categorias) {
            if (c.getNombre().equalsIgnoreCase(nombre)) {
                return c;
            }
        }
        return null;
    }
}