package com.example.Obligatorio.dtos;

public record VehiculoDTO(
        String matricula,
        String modelo,
        String color,
        int cantidadTransitos,
        double totalGastado
) {}
