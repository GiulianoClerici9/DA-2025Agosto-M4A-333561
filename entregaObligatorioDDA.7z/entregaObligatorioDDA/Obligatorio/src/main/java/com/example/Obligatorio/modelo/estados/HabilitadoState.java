package com.example.Obligatorio.modelo.estados;

public class HabilitadoState extends EstadoPropietario {


    public HabilitadoState() {}
    
    @Override
    public String getNombre() {
        return "Habilitado";
    }

    @Override
    public String toString() {
        return "Habilitado";
    }
}